#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>

struct biblia {
	char nome_livro[50];
	char nome_autores[50];
	int capitulo;
	int versiculo;
	
};
void tirarbuffer() {
		int c;
		while ((c = getchar()) != '\n' && c != EOF) {}
}
void livro(struct biblia* b) {

	printf("\nHistoria do livro de proverbios: proverbios foi feito por salom�o, filho de davi, onde o foco do livro � a sabedoria", b->nome_livro);
    
}
void autor(struct biblia* b) {

	printf("Nome do autor? Salom�o, filho de Rei Davi", b->nome_autores);
	tirarbuffer();

}
void capitulo(struct biblia* b) {
	printf("\nDigite o numero do capitulo: ", b->capitulo);
	scanf("%d", &b->capitulo);

}
void versiculo(struct biblia* b) {
	printf("Insira o versiculo:");
	scanf("%d", &b->versiculo);
	if (b->versiculo == 1) {
		printf("\nVersiculo 1: ""prov�rbios de Salom�o, filho de davi, rei de israel\n""", b->versiculo);
	}
	if (b->versiculo == 2) {
		printf("\nVersiculo 2: ""para se conhecer a sabedoria e a instru��o; para se entederem as palavras da prud�ncia\n""", b->versiculo);
	}
	if (b->versiculo == 3) {
		printf("\nVersiculo 3:""para se receber a instru��o do entendimento, justi�a, ju�zo e equidade\n""", b->versiculo);
		if (b->versiculo == 4) {
			printf("\nVersiculo 4: ""para dar ao simples ao simples prud�ncia, e aos jovens conhecimento e bom siso""", b->versiculo);
			if(b->versiculo == 5){
				printf("\nVersiculo 5:"" para o s�bio ouvir e crescer em sabedoria, e o instru�do adquirir s�bios conselhos""", b->versiculo);
				if (b->versiculo == 6) {
					printf("\nVersiculo 6: ""para entender prov�rbios e sua interpreta��o, como tamb�m as palavras dos s�bios e suas adivinha��es""\n", b->versiculo);
				}
			}
		}
	}

}
int main() {
	setlocale(LC_ALL, "portuguese");

	struct biblia b;

	int escolha = 0;
	printf("\t\t===Apenas versiculos de proverbios===\t\n");

	do {

		printf("\t\tMenu do livro de proverbios:\t\n");

		printf("1-Historia do livro de Prov�rbios\n");
		printf("2-Autor do livro de Prov�rbios\n");
		printf("3-Capitulos de Prov�rbios ");
		printf("4-Versiculo de prov�rbios\n");
		printf("5-Sair\n");

		printf("\nEscolha uma op��o: ");
		scanf("%d", &escolha);
		switch (escolha) {
		case 1:
			livro(&b);
			break;
		case 2:
			autor(&b);
			break;
		case 3:
			capitulo(&b);
			break;
		case 4:
			versiculo(&b);
			break;
		case 5:
				printf("Saindo do programa...");
				system("pause");
				break;
		}
	} while (escolha != 4);
	return 0;
}

