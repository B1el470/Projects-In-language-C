﻿namespace ex20m7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            lblproduto = new Label();
            button1 = new Button();
            lblpreço = new Label();
            txtproduto = new TextBox();
            txtpreço = new TextBox();
            txtquant = new TextBox();
            lblquantidade = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(279, 49);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(486, 262);
            dataGridView1.TabIndex = 0;
            // 
            // lblproduto
            // 
            lblproduto.AutoSize = true;
            lblproduto.Location = new Point(105, 44);
            lblproduto.Name = "lblproduto";
            lblproduto.Size = new Size(50, 15);
            lblproduto.TabIndex = 1;
            lblproduto.Text = "Produto";
            // 
            // button1
            // 
            button1.Location = new Point(105, 336);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 2;
            button1.Text = "Adicionar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblpreço
            // 
            lblpreço.AutoSize = true;
            lblpreço.Location = new Point(105, 144);
            lblpreço.Name = "lblpreço";
            lblpreço.Size = new Size(37, 15);
            lblpreço.TabIndex = 3;
            lblpreço.Text = "Preço";
            // 
            // txtproduto
            // 
            txtproduto.Location = new Point(105, 84);
            txtproduto.Name = "txtproduto";
            txtproduto.Size = new Size(100, 23);
            txtproduto.TabIndex = 4;
            // 
            // txtpreço
            // 
            txtpreço.Location = new Point(105, 176);
            txtpreço.Name = "txtpreço";
            txtpreço.Size = new Size(100, 23);
            txtpreço.TabIndex = 5;
            // 
            // txtquant
            // 
            txtquant.Location = new Point(105, 269);
            txtquant.Name = "txtquant";
            txtquant.Size = new Size(100, 23);
            txtquant.TabIndex = 7;
            // 
            // lblquantidade
            // 
            lblquantidade.AutoSize = true;
            lblquantidade.Location = new Point(105, 233);
            lblquantidade.Name = "lblquantidade";
            lblquantidade.Size = new Size(69, 15);
            lblquantidade.TabIndex = 8;
            lblquantidade.Text = "Quantidade";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(279, 344);
            label4.Name = "label4";
            label4.Size = new Size(35, 15);
            label4.TabIndex = 9;
            label4.Text = "Total:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SkyBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(lblquantidade);
            Controls.Add(txtquant);
            Controls.Add(txtpreço);
            Controls.Add(txtproduto);
            Controls.Add(lblpreço);
            Controls.Add(button1);
            Controls.Add(lblproduto);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label lblproduto;
        private Button button1;
        private Label lblpreço;
        private TextBox txtproduto;
        private TextBox txtpreço;
        private TextBox txtquant;
        private Label lblquantidade;
        private Label label4;
    }
}
