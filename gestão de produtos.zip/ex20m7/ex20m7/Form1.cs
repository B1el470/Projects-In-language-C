namespace ex20m7
{
    public partial class Form1 : Form
    {
        double total = 0;
        public Form1()
        {
            InitializeComponent();
            dataGridView1.AllowUserToAddRows = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string produto = txtproduto.Text;
            double preco = double.Parse(txtpre�o.Text);
            int qtd = int.Parse(txtquant.Text);
            double sub = preco * qtd;

            int i = dataGridView1.Rows.Add(produto, preco, qtd, sub);

            if (sub > 1000)
            
                dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.Red;

            total += sub;
            label4.Text = "Total:" + total + "�";

            txtproduto.Text = "";
            txtpre�o.Text = "";
            txtquant.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("Produto", "Produto");
            dataGridView1.Columns.Add("Pre�o", "Pre�o");
            dataGridView1.Columns.Add("Quantidade", "Quantidade");
            dataGridView1.Columns.Add("Subtotal", "Subtotal");

            dataGridView1.Columns["Subtotal"].Width = 300;

        }
    }
}
